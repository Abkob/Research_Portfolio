Gerber conversion for Fujifilm / Dimatix inkjet import

Source file: Gerber_TopLayer.GTL
Source units: millimeters
Gerber coordinate format: FSLAX45Y45, leading zeros omitted
Converted geometry: filled Gerber regions G36/G37 only

Output files:
1. PCB5_Fujifilm_TopLayer_1to1_NORMALIZED_mm.dxf
   - Same 1:1 size as Gerber, translated so lower-left bounding box is at X=0, Y=0.
   - Recommended for Fujifilm/pattern import because all coordinates are positive.

2. PCB5_Fujifilm_TopLayer_1to1_ORIGINAL_COORDS_mm.dxf
   - Same 1:1 size as Gerber and preserves original Gerber coordinate positions.
   - Original coordinates are negative because of the PCB CAD origin.

3. PCB5_Fujifilm_TopLayer_1to1_FILLED_NORMALIZED_mm.svg
   - Filled black vector preview/import file, same normalized dimensions.

Scale check:
- Bounding box width  = 12.68000 mm
- Bounding box height = 6.91200 mm
- Original min X/Y    = (-27.29700, -11.29100) mm
- Original max X/Y    = (-14.61700, -4.37900) mm
- Number of filled regions converted = 28

Important:
- Only the top copper Gerber contained printable geometry. Bottom copper, solder mask, silkscreen, and board outline were effectively empty in the uploaded zip.
- The DXF uses millimeter units and closed vector polylines. Do not scale or fit-to-page when importing.
